from colorama import Fore, Style

#10
surname = input("Введите фамилию: ")
N = int(input("Введите номер варианта N: "))

while N < 1 or N > 30:
    print("Введите номер от 1 до 30.")
    N = int(input("Введите номер варианта N: "))

#11
A = N % 5
B = N % 4
T = 65 + A
P = 75 + B

print(Fore.BLUE + "Комплексная работа" + "\n")
print(Fore.BLUE + "Фамилия:", surname)
print(Fore.BLUE + "Вариант:", str(N))
print(Fore.CYAN + "A =", A)
print(Fore.CYAN + "B =", B)
print(Fore.CYAN + "T =", T)
print(Fore.CYAN + "P =", P)
print(Style.RESET_ALL)

#12
data = [
    {
        "ID": 1,
        "Имя": "Анна",
        "Группа": "Альфа",
        "Тест1": 54,
        "Тест2": 62,
        "Тест3": 70,
        "Посещаемость": 70
    },
    {
        "ID": 2,
        "Имя": "Борис",
        "Группа": "Бета",
        "Тест1": 76,
        "Тест2": 80,
        "Тест3": 84,
        "Посещаемость": 82
    },
    {
        "ID": 3,
        "Имя": "Вера",
        "Группа": "Гамма",
        "Тест1": 88,
        "Тест2": 92,
        "Тест3": 86,
        "Посещаемость": 90
    },
    {
        "ID": 4,
        "Имя": "Глеб",
        "Группа": "Альфа",
        "Тест1": 60,
        "Тест2": "",
        "Тест3": 68,
        "Посещаемость": 76
    },
    {
        "ID": 5,
        "Имя": "Дарья",
        "Группа": "Бета",
        "Тест1": 70,
        "Тест2": 74,
        "Тест3": 78,
        "Посещаемость": 79
    },
    {
        "ID": 6,
        "Имя": "Егор",
        "Группа": "Гамма",
        "Тест1": 40,
        "Тест2": 55,
        "Тест3": 50,
        "Посещаемость": 68
    },
    {
        "ID": 7,
        "Имя": "Жанна",
        "Группа": "Альфа",
        "Тест1": 80,
        "Тест2": 84,
        "Тест3": 88,
        "Посещаемость": 92
    },
    {
        "ID": 8,
        "Имя": "Захар",
        "Группа": "Бета",
        "Тест1": 58,
        "Тест2": 64,
        "Тест3": 60,
        "Посещаемость": 74
    },
    {
        "ID": 9,
        "Имя": "Ирина",
        "Группа": "Гамма",
        "Тест1": 90,
        "Тест2": 94,
        "Тест3": 92,
        "Посещаемость": 95
    },
    {
        "ID": 10,
        "Имя": "Кирилл",
        "Группа": "Альфа",
        "Тест1": 66,
        "Тест2": 70,
        "Тест3": 72,
        "Посещаемость": 80
    },
    {
        "ID": 11,
        "Имя": "Лена",
        "Группа": "Бета",
        "Тест1": 72,
        "Тест2": "",
        "Тест3": 76,
        "Посещаемость": 77
    },
    {
        "ID": 12,
        "Имя": "Максим",
        "Группа": "Гамма",
        "Тест1": 48,
        "Тест2": 52,
        "Тест3": 56,
        "Посещаемость": 72
    }
]

#13
for person in data:
    person["Тест1"] += A
    if person["Тест2"] != "":
        person["Тест2"] += A
    person["Тест3"] += A
    person["Посещаемость"] += B

print("Первый участник:")
print(data[0])
print("Последний участник:")
print(data[-1])
print("Группа первого участника:", data[0]["Группа"])
print("Количество участников:", len(data))

groups = ["Альфа", "Бета", "Гамма"]
group_name = input("Введите название группы: ")
if group_name in groups:
    print("Такая группа существует.")
else:
    print("Такой группы нет.")

names = ["Анна", "Борис", "Вера"]
print("Длина до добавления:", len(names))
names.append("Временное имя")
print("После append:", names)
names.pop()
print("После pop:", names)
print("Длина после удаления:", len(names))


total_scores = 0
count_scores = 0
admitted_count = 0
missing_count = 0

for person in data:
    #16
    missing_test2 = person["Тест2"] == ""

    if missing_test2:
        test2 = 0
        missing_count += 1
    else:
        test2 = person["Тест2"]

    #17
    total = person["Тест1"] + test2 + person["Тест3"]
    average = total / 3

    person["Сумма"] = total
    person["Среднее"] = round(average, 2)

    if average >= 85:
        person["Уровень"] = "высокий"
    elif average >= T:
        person["Уровень"] = "базовый"
    else:
        person["Уровень"] = "требуется подготовка"

    admitted = (
        average >= T
        and person["Посещаемость"] >= P
        and not missing_test2
    )

    person["Допуск"] = admitted

    #18
    reasons = []

    if average < T:
        reasons.append("низкое среднее")

    if person["Посещаемость"] < P:
        reasons.append("низкая посещаемость")

    if missing_test2:
        reasons.append("отсутствует результат теста")

    person["Причины отказа"] = reasons

    #19
    total_scores += total
    count_scores += 3

    if admitted:
        admitted_count += 1

overall_average = total_scores / count_scores

print("Порог среднего балла:", T)
print("Порог посещаемости:", P)
print("Количество участников:", len(data))
print("Количество допущенных:", admitted_count)
print("Количество отсутствующих результатов:", missing_count)
print("Общий средний балл:", round(overall_average, 2))

#20
import os
import csv

os.makedirs("data", exist_ok=True)

with open("data/source.csv", "w", encoding="utf-8", newline="") as file:
    writer = csv.writer(file)

    writer.writerow([
        "ID", "Имя", "Группа", "Тест1",
        "Тест2", "Тест3", "Посещаемость"
    ])

    for person in data:
        writer.writerow([
            person["ID"],
            person["Имя"],
            person["Группа"],
            person["Тест1"],
            person["Тест2"],
            person["Тест3"],
            person["Посещаемость"]
        ])

#21
import os

os.makedirs("results", exist_ok=True)

with open("results/python_report.txt", "w", encoding="utf-8") as file:
    file.write("Исполнитель: " + surname + "\n")
    file.write("Вариант: " + str(N) + "\n")
    file.write("A = " + str(A) + ", B = " + str(B) + ", T = " + str(T) + ", P = " + str(P) + "\n\n")

    file.write("Результаты участников:\n")

    for person in data:
        file.write("ID: " + str(person["ID"]) + "; ")
        file.write("Среднее: " + str(person["Среднее"]) + "; ")
        file.write("Уровень: " + person["Уровень"] + "; ")
        file.write("Допуск: " + str(person["Допуск"]) + "; ")
        file.write("Причины отказа: " + (", ".join(person["Причины отказа"]) or "нет") + "\n")

    file.write("\nОбщая статистика:\n")
    file.write("Сумма баллов: " + str(total_scores) + "\n")
    file.write("Среднее всех результатов: " + str(round(overall_average, 2)) + "\n")
    file.write("Количество допущенных: " + str(admitted_count) + "\n")

#22
with open("data/source.csv", "r", encoding="utf-8") as file:
    lines = file.readlines()

print("Первые три строки файла:")
for line in lines[:3]:
    print(line.rstrip())

data_rows = 0

with open("data/source.csv", "r", encoding="utf-8") as file:
    next(file)

    for line in file:
        data_rows += 1

print("Количество строк данных:", data_rows)

#23
with open("journal.txt", "a", encoding="utf-8") as file:
    file.write("Этап 3 завершён.\n")
    file.write("Вариант: " + str(N) + "\n")
    file.write("Проверено строк CSV: " + str(data_rows) + "\n")
    file.write("Допущено участников: " + str(admitted_count) + "\n")
    file.write("------------------------------\n")

print("Участник ID 1:")
print(data[0])

print("Участник ID 4:")
print(data[3])