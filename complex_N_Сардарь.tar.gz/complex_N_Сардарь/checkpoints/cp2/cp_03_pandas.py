import pandas as pd

#31
N = 21
A = N % 5
B = N % 4
T = 65 + A
P = 75 + B

data = pd.read_csv("data/source.csv")

print("Первые строки:")
print(data.head())

print("Последние строки:")
print(data.tail())

print("Размер таблицы:")
print(data.shape)

print("Названия столбцов:")
print(data.columns)

print("Типы данных:")
print(data.dtypes)

print("Информация о таблице:")
data.info()

print("Описание числовых столбцов:")
print(data.describe())

#32
data["Пропуск_Тест2"] = data["Тест2"].isna()

print("Пропуски по столбцам:")
print(data.isna().sum())

print("Количество пропусков Тест2:")
print(data["Пропуск_Тест2"].sum())

#33
data_drop = data.dropna()

print("Количество строк после dropna:")
print(data_drop.shape[0])

print("ID, которые удалились бы:")
print(data.loc[~data.index.isin(data_drop.index), "ID"])

data["Тест2"] = data["Тест2"].fillna(0)

print("Пропуски после заполнения:")
print(data.isna().sum())

#34
data["Сумма"] = data["Тест1"] + data["Тест2"] + data["Тест3"]
data["Среднее"] = data["Сумма"] / 3

levels = []

for average in data["Среднее"]:
    if average >= 85:
        levels.append("высокий")
    elif average >= T:
        levels.append("базовый")
    else:
        levels.append("требуется подготовка")

data["Уровень"] = levels

#35
data["Допуск"] = (
    (data["Среднее"] >= T)
    & (data["Посещаемость"] >= P)
    & (~data["Пропуск_Тест2"])
)

print("Среднее, уровень и допуск:")
print(data[["ID", "Среднее", "Уровень", "Допуск"]])

#36
data["Среднее_округл"] = data["Среднее"].round(2)

print("Округлённое среднее:")
print(data[["ID", "Среднее", "Среднее_округл"]])

#37
averages_series = pd.Series(
    data["Среднее"].values,
    index=data["ID"]
)

print("Среднее участника ID 4:")
print(averages_series.loc[4])

data_indexed = data.set_index("ID")

print("loc[4]:")
print(data_indexed.loc[4])

print("iloc[3]:")
print(data_indexed.iloc[3])

#38
data.to_csv("results/cleaned.csv", index=False, encoding="utf-8")

cleaned = pd.read_csv("results/cleaned.csv")

print("Количество строк:")
print(cleaned.shape[0])

print("Количество столбцов:")
print(cleaned.shape[1])

print("Список ID:")
print(cleaned["ID"].tolist())

print("Пропуски после сохранения:")
print(cleaned.isna().sum())

print("Количество исходных пропусков Тест2:")
print(cleaned["Пропуск_Тест2"].sum())

#39
print("Общая сумма Pandas:")
print(data["Сумма"].sum())

print("Общее среднее Pandas:")
print(data["Сумма"].sum() / 36)

print("Количество допущенных Pandas:")
print(data["Допуск"].sum())

print("Ожидаемая сумма Python и NumPy: 2443")
print("Ожидаемое среднее Python и NumPy:", 2443 / 36)
print("Ожидаемое количество допущенных: 6")