import pandas as pd

#31
N = 21
A = N % 5
B = N % 4
T = 65 + A
P = 75 + B

data = pd.read_csv("data/source.csv")

print("Первые строки:")
print(data.head())

print("Последние строки:")
print(data.tail())

print("Размер таблицы:")
print(data.shape)

print("Названия столбцов:")
print(data.columns)

print("Типы данных:")
print(data.dtypes)

print("Информация о таблице:")
data.info()

print("Описание числовых столбцов:")
print(data.describe())

#32
data["Пропуск_Тест2"] = data["Тест2"].isna()

print("Пропуски по столбцам:")
print(data.isna().sum())

print("Количество пропусков Тест2:")
print(data["Пропуск_Тест2"].sum())

#33
data_drop = data.dropna()

print("Количество строк после dropna:")
print(data_drop.shape[0])

print("ID, которые удалились бы:")
print(data.loc[~data.index.isin(data_drop.index), "ID"])

data["Тест2"] = data["Тест2"].fillna(0)

print("Пропуски после заполнения:")
print(data.isna().sum())

#34
data["Сумма"] = data["Тест1"] + data["Тест2"] + data["Тест3"]
data["Среднее"] = data["Сумма"] / 3

levels = []

for average in data["Среднее"]:
    if average >= 85:
        levels.append("высокий")
    elif average >= T:
        levels.append("базовый")
    else:
        levels.append("требуется подготовка")

data["Уровень"] = levels

#35
data["Допуск"] = (
    (data["Среднее"] >= T)
    & (data["Посещаемость"] >= P)
    & (~data["Пропуск_Тест2"])
)

print("Среднее, уровень и допуск:")
print(data[["ID", "Среднее", "Уровень", "Допуск"]])

#36
data["Среднее_округл"] = data["Среднее"].round(2)

print("Округлённое среднее:")
print(data[["ID", "Среднее", "Среднее_округл"]])

#37
averages_series = pd.Series(
    data["Среднее"].values,
    index=data["ID"]
)

print("Среднее участника ID 4:")
print(averages_series.loc[4])

data_indexed = data.set_index("ID")

print("loc[4]:")
print(data_indexed.loc[4])

print("iloc[3]:")
print(data_indexed.iloc[3])

#38
data.to_csv("results/cleaned.csv", index=False, encoding="utf-8")

cleaned = pd.read_csv("results/cleaned.csv")

print("Количество строк:")
print(cleaned.shape[0])

print("Количество столбцов:")
print(cleaned.shape[1])

print("Список ID:")
print(cleaned["ID"].tolist())

print("Пропуски после сохранения:")
print(cleaned.isna().sum())

print("Количество исходных пропусков Тест2:")
print(cleaned["Пропуск_Тест2"].sum())

#39
print("Общая сумма Pandas:")
print(data["Сумма"].sum())

print("Общее среднее Pandas:")
print(data["Сумма"].sum() / 36)

print("Количество допущенных Pandas:")
print(data["Допуск"].sum())

print("Ожидаемая сумма Python и NumPy: 2443")
print("Ожидаемое среднее Python и NumPy:", 2443 / 36)
print("Ожидаемое количество допущенных: 6")

#40
admitted = data.loc[data["Допуск"] == True].copy()

admitted = admitted.sort_values(
    ["Среднее", "ID"],
    ascending=[False, True]
)

admitted = admitted[
    ["ID", "Имя", "Группа", "Среднее", "Посещаемость"]
]

admitted.to_csv(
    "results/admitted.csv",
    index=False,
    encoding="utf-8"
)

print("Допущенные участники:")
print(admitted)


#41
data["Причина_низкое_среднее"] = data["Среднее"] < T
data["Причина_низкая_посещаемость"] = data["Посещаемость"] < P
data["Причина_пропуск"] = data["Пропуск_Тест2"]

attention = data.loc[
    (data["Среднее"] < T)
    | (data["Посещаемость"] < P)
    | (data["Пропуск_Тест2"])
].copy()

attention = attention[
    [
        "ID", "Имя", "Группа", "Среднее", "Посещаемость",
        "Причина_низкое_среднее",
        "Причина_низкая_посещаемость",
        "Причина_пропуск"
    ]
]

attention.to_csv(
    "results/attention.csv",
    index=False,
    encoding="utf-8"
)

print("Участники, требующие внимания:")
print(attention)


#42
strong_attendance = data.loc[
    (data["Среднее"] >= T)
    & (data["Посещаемость"] >= P)
].copy()

strong_attendance = strong_attendance.sort_values(
    ["Среднее", "ID"],
    ascending=[False, True]
)

strong_attendance.to_csv(
    "results/strong_attendance.csv",
    index=False,
    encoding="utf-8"
)

print("Достаточный средний балл и посещаемость:")
print(strong_attendance)

print("Количество в strong_attendance:", len(strong_attendance))
print("Количество допущенных:", len(admitted))


#43
if N % 3 == 0:
    selected_group = "Альфа"
elif N % 3 == 1:
    selected_group = "Бета"
else:
    selected_group = "Гамма"

group_selection = data.loc[
    data["Группа"] == selected_group
].copy()

group_selection = group_selection.sort_values(
    ["Среднее", "ID"],
    ascending=[False, True]
)

group_selection.to_csv(
    "results/group_selection.csv",
    index=False,
    encoding="utf-8"
)

print("Выбранная группа:", selected_group)
print(group_selection)

#44
summary = data.groupby("Группа").agg(
    Среднее_группы=("Среднее", "mean"),
    Минимум=("Среднее", "min"),
    Максимум=("Среднее", "max"),
    Количество=("ID", "count"),
    Средняя_посещаемость=("Посещаемость", "mean"),
    Допущено=("Допуск", "sum")
).reset_index()

summary = summary.rename(columns={"Группа": "Группа"})

#45
summary = summary.sort_values(
    ["Среднее_группы", "Группа"],
    ascending=[False, True]
)

summary.to_csv(
    "results/summary.csv",
    index=False,
    encoding="utf-8"
)

print("Сводка по группам:")
print(summary)


#46
source_before_fill = pd.read_csv("data/source.csv")

print("Количество непустых результатов Тест2 до заполнения:")
print(source_before_fill["Тест2"].count())

print("Количество непустых результатов Тест2 после заполнения:")
print(data["Тест2"].count())


#47
admitted_ids = set(admitted["ID"])
attention_ids = set(attention["ID"])

print("Пересечение выборок:")
print(admitted_ids & attention_ids)

print("Все ID в двух выборках:")
print(sorted(admitted_ids | attention_ids))

print("Количество ID в объединении:")
print(len(admitted_ids | attention_ids))


#48
manual_group = "Альфа"

group_means = data.loc[
    data["Группа"] == manual_group,
    "Среднее"
]

manual_average = (
    group_means.iloc[0]
    + group_means.iloc[1]
    + group_means.iloc[2]
    + group_means.iloc[3]
) / 4

group_average = summary.loc[
    summary["Группа"] == manual_group,
    "Среднее_группы"
].iloc[0]

print("Группа для ручной проверки:", manual_group)
print("Среднее вручную:", manual_average)
print("Среднее через groupby:", group_average)
print("Разница:", abs(manual_average - group_average))