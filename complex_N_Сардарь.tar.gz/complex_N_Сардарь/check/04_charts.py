import pandas as pd
import matplotlib.pyplot as plt

N = 21

#49
data = pd.read_csv("results/cleaned.csv")
summary = pd.read_csv("results/summary.csv")

plt.rcParams["font.family"] = "DejaVu Sans"

plt.figure(figsize=(8, 5))

plt.bar(
    summary["Группа"],
    summary["Среднее_группы"]
)

plt.title("Средний результат по группам, вариант N = 21")
plt.xlabel("Группа")
plt.ylabel("Средний балл")
plt.grid(axis="y", alpha=0.3)

plt.tight_layout()
plt.savefig("results/group_average.png")
plt.show()
plt.close()


#50
participants = data.sort_values("ID")

plt.figure(figsize=(10, 5))

plt.plot(
    participants["ID"],
    participants["Среднее"],
    marker="o"
)

for _, person in participants.iterrows():
    plt.annotate(
        str(int(person["ID"])),
        (person["ID"], person["Среднее"]),
        xytext=(0, 7),
        textcoords="offset points",
        ha="center"
    )

plt.title("Средние результаты участников, вариант N = 21")
plt.xlabel("ID участника")
plt.ylabel("Средний балл")
plt.xticks(participants["ID"])
plt.grid(axis="y", alpha=0.3)

plt.tight_layout()
plt.savefig("results/participants.png")
plt.show()
plt.close()


#51
admission_by_group = data.groupby("Группа").agg(
    Допущено=("Допуск", "sum")
).reindex(summary["Группа"])

plt.figure(figsize=(8, 5))

plt.bar(
    admission_by_group.index,
    admission_by_group["Допущено"]
)

plt.title("Количество допущенных по группам, вариант N = 21")
plt.xlabel("Группа")
plt.ylabel("Количество допущенных")
plt.yticks(range(5))
plt.ylim(0, 4)
plt.grid(axis="y", alpha=0.3)

plt.tight_layout()
plt.savefig("results/admission.png")
plt.show()
plt.close()


#52
print("Диаграммы сохранены:")
print("results/group_average.png")
print("results/participants.png")
print("results/admission.png")


#53
print("Количество диаграмм:", 3)
print("Количество участников:", len(data))
print("Количество групп:", len(summary))

print("Средние результаты по группам:")
print(summary[["Группа", "Среднее_группы"]])

print("Количество допущенных по группам:")
print(admission_by_group)

#63
import pandas as pd

cleaned = pd.read_csv("results/cleaned.csv")

total_scores = cleaned["Сумма"].sum()
overall_average = total_scores / 36
admitted_count = cleaned["Допуск"].sum()

#66
print("Проверка варианта:", N)
print("Количество участников:", len(data))

#67
source_before_fill = pd.read_csv("data/source.csv")
cleaned = pd.read_csv("results/cleaned.csv")

print("Пропуски Тест2 в source.csv:")
print(source_before_fill["Тест2"].isna().sum())

print("Пропуски Тест2 в cleaned.csv:")
print(cleaned["Тест2"].isna().sum())

print("Сохранённые признаки пропусков:")
print(cleaned["Пропуск_Тест2"].sum())

#68
print("Проверка среднего и допуска:")
print(cleaned[["ID", "Среднее", "Среднее_округл", "Допуск"]])

#69
print("Сумма баллов:", cleaned["Сумма"].sum())
print("Среднее баллов:", cleaned["Сумма"].sum() / 36)
print("Количество допущенных:", cleaned["Допуск"].sum())

#70
print("Количество участников по группам:")
print(cleaned.groupby("Группа")["ID"].count())

print("Количество допущенных по группам:")
print(cleaned.groupby("Группа")["Допуск"].sum())

#71
print("Проверка повторного запуска завершена.")
print("Количество строк в source.csv:", len(source_before_fill))

#72
print("Все основные программы проекта подготовлены.")