import pandas as pd
import matplotlib.pyplot as plt

#49
data = pd.read_csv("results/cleaned.csv")
summary = pd.read_csv("results/summary.csv")

plt.rcParams["font.family"] = "DejaVu Sans"

plt.figure(figsize=(8, 5))

plt.bar(
    summary["Группа"],
    summary["Среднее_группы"]
)

plt.title("Средний результат по группам, вариант N = 21")
plt.xlabel("Группа")
plt.ylabel("Средний балл")
plt.grid(axis="y", alpha=0.3)

plt.tight_layout()
plt.savefig("results/group_average.png")
plt.show()
plt.close()


#50
participants = data.sort_values("ID")

plt.figure(figsize=(10, 5))

plt.plot(
    participants["ID"],
    participants["Среднее"],
    marker="o"
)

for _, person in participants.iterrows():
    plt.annotate(
        str(int(person["ID"])),
        (person["ID"], person["Среднее"]),
        xytext=(0, 7),
        textcoords="offset points",
        ha="center"
    )

plt.title("Средние результаты участников, вариант N = 21")
plt.xlabel("ID участника")
plt.ylabel("Средний балл")
plt.xticks(participants["ID"])
plt.grid(axis="y", alpha=0.3)

plt.tight_layout()
plt.savefig("results/participants.png")
plt.show()
plt.close()


#51
admission_by_group = data.groupby("Группа").agg(
    Допущено=("Допуск", "sum")
).reindex(summary["Группа"])

plt.figure(figsize=(8, 5))

plt.bar(
    admission_by_group.index,
    admission_by_group["Допущено"]
)

plt.title("Количество допущенных по группам, вариант N = 21")
plt.xlabel("Группа")
plt.ylabel("Количество допущенных")
plt.yticks(range(5))
plt.ylim(0, 4)
plt.grid(axis="y", alpha=0.3)

plt.tight_layout()
plt.savefig("results/admission.png")
plt.show()
plt.close()


#52
print("Диаграммы сохранены:")
print("results/group_average.png")
print("results/participants.png")
print("results/admission.png")


#53
print("Количество диаграмм:", 3)
print("Количество участников:", len(data))
print("Количество групп:", len(summary))

print("Средние результаты по группам:")
print(summary[["Группа", "Среднее_группы"]])

print("Количество допущенных по группам:")
print(admission_by_group)