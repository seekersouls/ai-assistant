import numpy as np

#24
N = 21
A = N % 5
B = N % 4
T = 65 + A
P = 75 + B

M = np.array([
    [55, 63, 71],
    [77, 81, 85],
    [89, 93, 87],
    [61, 0, 69],
    [71, 75, 79],
    [41, 56, 51],
    [81, 85, 89],
    [59, 65, 61],
    [91, 95, 93],
    [67, 71, 73],
    [73, 0, 77],
    [49, 53, 57]
])

attendance = np.array([
    71, 83, 91, 77, 80, 69,
    93, 75, 96, 81, 78, 73
])

print("Тип массива:", type(M))
print("Тип данных:", M.dtype)
print("Количество измерений:", M.ndim)
print("Размер массива:", M.shape)
print("Количество элементов:", M.size)

#25
print("Первая строка:")
print(M[0])

print("Последняя строка:")
print(M[-1])

print("Второй столбец:")
print(M[:, 1])

print("Первые четыре строки и первые два столбца:")
print(M[:4, :2])

#26
sums = M.sum(axis=1)
averages = M.mean(axis=1)

print("Суммы по участникам:")
print(sums)

print("Средние по участникам:")
print(averages)

print("Средние по тестам:")
print(M.mean(axis=0))

print("Общая сумма:", M.sum())
print("Общее среднее:", M.mean())
print("Минимальный балл:", M.min())
print("Максимальный балл:", M.max())

#27
ids = np.arange(1, 13)

mask_average = averages >= T
mask_attendance = attendance < P

print("ID со средним не ниже T:")
print(ids[mask_average])

print("ID с посещаемостью ниже P:")
print(ids[mask_attendance])

print("ID со средним не ниже T и посещаемостью ниже P:")
print(ids[mask_average & mask_attendance])

#28
numbers = np.arange(1, 37)
numbers_12_3 = numbers.reshape(12, 3)

print("Числа от 1 до 36:")
print(numbers)

print("Массив 12 на 3:")
print(numbers_12_3)

numbers_35 = np.arange(1, 36)

print("В массиве из 35 чисел нельзя создать форму 12 на 3,")
print("потому что для неё нужно 36 элементов.")

#29
zeros = np.zeros((12, 3))
ones = np.ones((12, 3))

print("Массив нулей:")
print(zeros)

print("Массив единиц:")
print(ones)

print("Сумма массивов:")
print(zeros + ones)

total_scores = M.sum()
overall_average = total_scores / M.size

#30
with open("results/numpy_report.txt", "w", encoding="utf-8") as file:
    file.write("Отчёт NumPy\n")
    file.write("Общая сумма NumPy: " + str(M.sum()) + "\n")
    file.write("Общее среднее NumPy: " + str(M.mean()) + "\n")
    file.write("Общая сумма Python: " + str(total_scores) + "\n")
    file.write("Общее среднее Python: " + str(overall_average) + "\n")

# Исследование изменения одного значения

M_copy = M.copy()

print("Исходная сумма:", M.sum())
print("Исходное среднее:", M.mean())
print("Исходная сумма ID 1:", M[0].sum())
print("Исходное среднее ID 1:", M[0].mean())

M_copy[0, 2] = M_copy[0, 2] + 6

print("Новая сумма:", M_copy.sum())
print("Новое среднее:", M_copy.mean())
print("Новая сумма ID 1:", M_copy[0].sum())
print("Новое среднее ID 1:", M_copy[0].mean())

print("Исходная матрица не изменилась:")
print(M)