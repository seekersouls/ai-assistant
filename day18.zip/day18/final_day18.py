from pathlib import Path
import csv

# Функция разбиения текста на чанки

def split_into_chunks(text, chunk_size, overlap, minimum_length):

    if chunk_size < 200:
        raise ValueError("chunk_size должен быть не меньше 200")

    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("Некорректное значение overlap")

    chunks = []

    step = chunk_size - overlap

    for start in range(0, len(text), step):
        chunk = text[start:start + chunk_size].strip()

        if chunk != "":
            if len(chunk) >= minimum_length:
                chunks.append(chunk)

    return chunks

# Параметры чанкинга

chunk_size = 200
overlap = 40
minimum_length = 20

# Находим документы

source_dir = Path("normalized")
files = list(source_dir.glob("*.txt"))

print("Найдено документов:", len(files))

if len(files) < 6:
    print("Ошибка: необходимо минимум 6 документов")

# Создаём общий список чанков

all_chunks = []

for file_path in files:

    text = file_path.read_text(encoding="utf-8")

    chunks = split_into_chunks(
        text,
        chunk_size,
        overlap,
        minimum_length
    )

    for chunk_id, chunk in enumerate(chunks):

        all_chunks.append({
            "source": file_path.name,
            "chunk_id": chunk_id,
            "text": chunk,
            "length": len(chunk)
        })

# Создаём папку chunks

chunks_dir = Path("chunks")
chunks_dir.mkdir(exist_ok=True)

# Сохраняем каждый чанк

for chunk in all_chunks:

    source_stem = Path(chunk["source"]).stem

    filename = source_stem + "_chunk_" + str(chunk["chunk_id"]) + ".txt"

    output_path = chunks_dir / filename

    output_path.write_text(
        chunk["text"],
        encoding="utf-8"
    )

# Создаём CSV-сводку

with open("chunks_summary.csv", "w", encoding="utf-8", newline="") as file:

    writer = csv.writer(file)

    writer.writerow(["source", "chunk_id", "length"])

    for chunk in all_chunks:

        writer.writerow([
            chunk["source"],
            chunk["chunk_id"],
            chunk["length"]
        ])

# Вычисляем среднюю длину чанка

total_length = 0

for chunk in all_chunks:
    total_length = total_length + chunk["length"]


if len(all_chunks) > 0:

    average = total_length / len(all_chunks)

else:
    average = 0

# Выводим итоговую статистику

print("Количество документов:", len(files))
print("Всего чанков:", len(all_chunks))
print("Средняя длина чанка:", round(average, 1))
