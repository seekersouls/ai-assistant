from pathlib import Path


def split_with_overlap(text, chunk_size, overlap):
    chunks = []
    step = chunk_size - overlap

    for start in range(0, len(text), step):
        chunk = text[start:start + chunk_size]
        chunks.append(chunk)

    return chunks

source_dir = Path("normalized")
files = list(source_dir.glob("*.txt"))

all_chunks = []

for file_path in files:
    text = file_path.read_text(encoding="utf-8")
    chunks = split_with_overlap(text, 200, 40)

    for chunk_id, chunk in enumerate(chunks):
        all_chunks.append({
            "source": file_path.name,
            "chunk_id": chunk_id,
            "text": chunk,
            "length": len(chunk)
        })

chunks_dir = Path("chunks")
chunks_dir.mkdir(exist_ok=True)

for chunk in all_chunks:
    source_stem = Path(chunk["source"]).stem

    filename = source_stem + "_chunk_" + str(chunk["chunk_id"]) + ".txt"

    output_path = chunks_dir / filename

    output_path.write_text(chunk["text"], encoding="utf-8")

import csv

with open("chunks_summary.csv", "w", encoding="utf-8", newline="") as file:
    writer = csv.writer(file)

    writer.writerow(["source", "chunk_id", "length"])

    for chunk in all_chunks:
        writer.writerow([
            chunk["source"],
            chunk["chunk_id"],
            len(chunk["text"])
        ])

chunk_size = 100
overlap = 40

filename = file_path.stem + "_chunk_" + str(chunk_id) + ".txt"
