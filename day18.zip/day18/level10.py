from pathlib import Path
import csv

def split_into_chunks(text, chunk_size, overlap):
    chunks = []

    step = chunk_size - overlap

    for start in range(0, len(text), step):
        chunk = text[start:start + chunk_size]
        chunks.append(chunk)

    return chunks

# Папка с исходными документами

source_dir = Path("normalized")
files = list(source_dir.glob("*.txt"))

print("Найдено документов:", len(files))

# Общий список чанков

all_chunks = []

for file_path in files:
    text = file_path.read_text(encoding="utf-8")

    chunks = split_into_chunks(text, 200, 40)

    for chunk_id, chunk in enumerate(chunks):
        all_chunks.append({
            "source": file_path.name,
            "chunk_id": chunk_id,
            "text": chunk,
            "length": len(chunk)
        })

# Папка для чанков

chunks_dir = Path("chunks")
chunks_dir.mkdir(exist_ok=True)

# Сохраняем каждый чанк

for chunk in all_chunks:
    source_stem = Path(chunk["source"]).stem

    filename = source_stem + "_chunk_" + str(chunk["chunk_id"]) + ".txt"

    output_path = chunks_dir / filename

    output_path.write_text(chunk["text"], encoding="utf-8")

# CSV-сводка

with open("chunks_summary.csv", "w", encoding="utf-8", newline="") as file:
    writer = csv.writer(file)

    writer.writerow(["source", "chunk_id", "length"])

    for chunk in all_chunks:
        writer.writerow([
            chunk["source"],
            chunk["chunk_id"],
            chunk["length"]
        ])

# Статистика

print("Документов:", len(files))
print("Всего чанков:", len(all_chunks))

print("Чанки сохранены")
print("CSV-сводка создана!")