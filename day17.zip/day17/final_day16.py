from pathlib import Path

def clean_text(text):
    lines = text.splitlines()
    clean_lines = []

    for line in lines:
        line = line.strip()
        if line != "":
            clean_lines.append(line)

    return "\n".join(clean_lines)


corpus_dir = Path("corpus_final")
cleaned_dir = Path("cleaned")

cleaned_dir.mkdir(exist_ok=True)

files = list(corpus_dir.glob("*.txt"))

documents = []

for file_path in files:
    text = file_path.read_text(encoding="utf-8")

    if text.strip() == "":
        print("Пропущен пустой файл:", file_path.name)
        continue

    text = clean_text(text)

    if text == "":
        print("Пропущен пустой файл:", file_path.name)
        continue

    document = {
        "source": file_path.name,
        "text": text
    }

    documents.append(document)

    output_path = cleaned_dir / file_path.name
    output_path.write_text(text, encoding="utf-8")


print("Итоговая сводка корпуса")

print("Количество документов:", len(documents))

total_chars = 0

for document in documents:
    chars = len(document["text"])
    total_chars = total_chars + chars

    print(document["source"], "—", chars, "символов")

    if chars < 50:
        print("Предупреждение: короткий документ", document["source"])

print("Всего символов:", total_chars)