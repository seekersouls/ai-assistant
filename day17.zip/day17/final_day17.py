from pathlib import Path


def clean_line(line):
    line = line.replace("\u00a0", " ")
    line = line.replace("\t", " ")
    line = " ".join(line.split())
    return line


def normalize_text(text):
    lines = text.splitlines()
    clean_lines = []
    seen = set()

    for line in lines:
        line = clean_line(line)

        if line == "":
            continue

        if line not in seen:
            clean_lines.append(line)
            seen.add(line)

    return "\n".join(clean_lines)


source_dir = Path("cleaned")
normalized_dir = Path("normalized")

normalized_dir.mkdir(exist_ok=True)

files = list(source_dir.glob("*.txt"))

total_before = 0
total_after = 0
empty_files = []

for file in files:
    text = file.read_text(encoding="utf-8")

    before = len(text)
    total_before = total_before + before

    normalized_text = normalize_text(text)

    after = len(normalized_text)
    total_after = total_after + after

    new_file = normalized_dir / file.name
    new_file.write_text(normalized_text, encoding="utf-8")

    print("Файл:", file.name)
    print("Размер до:", before)
    print("Размер после:", after)
    print("--------------------")

    if normalized_text.strip() == "":
        empty_files.append(file.name)


print("Всего документов:", len(files))
print("Общий размер до:", total_before)
print("Общий размер после:", total_after)

if total_before > 0:
    reduction = (total_before - total_after) / total_before * 100
    print("Процент сокращения:", round(reduction, 2), "%")
else:
    print("Исходный корпус пустой")

if len(empty_files) == 0:
    print("Пустых документов после очистки нет")
else:
    print("Пустые документы:", empty_files)