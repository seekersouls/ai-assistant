def clean_line(line):
    line = line.replace("\t", " ")
    line = " ".join(line.split())
    return line


def normalize_text(text):
    lines = text.splitlines()
    clean_lines = []

    for line in lines:
        line = clean_line(line)

        if line != "":
            clean_lines.append(line)

    unique_lines = []

    for line in clean_lines:
        if line not in unique_lines:
            unique_lines.append(line)

    return "\n".join(unique_lines)

from pathlib import Path

cleaned_dir = Path("cleaned")

normalized_dir = Path("normalized")
normalized_dir.mkdir(exist_ok=True)

files = list(cleaned_dir.glob("*.txt"))

print("Текущая папка:", Path.cwd())
print("Папка cleaned существует:", cleaned_dir.exists())
print("Найденные файлы:", files)